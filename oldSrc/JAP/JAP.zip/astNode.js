module.exports = ASTNode;

var ASTMap = require('./astMap.js');

function ASTNode(ast, node, path){
	this.ast = ast;
	this.node = node || arguments[0];
	this.path = path || '/';
	this.map = new ASTMap(ast);
}


ASTNode.prototype.find = function(rejex){
	return mapResultsToNodes(this.ast, this.map.find(rejex));
}

ASTNode.prototype.findByPath = function(path){
	var node = this.map.getNodeByPath(path);
	if(!node) return null
	return new ASTNode(this.ast, node, path);
}

ASTNode.prototype.parent = function(){
	var parentPath = this.getParentPath(this.path);
	return this.getNodeByPath(parentPath);
}

ASTNode.prototype.blockParent = function(){
	var match = /(.+[0-9+]\/[a-z|A-Z]+)/.exec(this.path);
	if(match === null)return null;
	var blockParent = match[1];
	return this.findByPath(blockParent);
}

ASTNode.prototype.parentBlock = function(){
	var match = /(.+)[0-9+]/.exec(this.path);
	if(match === null)return null;
	var parentBlock = this.getParentPath(match[1]);
	return this.findByPath(parentBlock);
}

ASTNode.prototype.getParentPath = function(path){
	var parts = path.split('/');
	parts.splice(parts.length-1,1);
	return parts.join('/')
}

ASTNode.prototype.getBlockIndex = function(){
	var match = /(.+)[0-9+]/.exec(this.path);
	var parts = match[1].split('/');
	var index = parts.splice(parts.length-1,1);
	return index;
}

ASTNode.prototype.remove = function(){
	var index = this.getBlockIndex();
	var block = this.parentBlock();
	return block.node.body.splice(index,1) ? true : false;
}

ASTNode.prototype.insertBefore = function(newSiblingNode){
	var index = this.getBlockIndex();
	var block = this.parentBlock();
	return block.node.body.splice(index,0,newSiblingNode.ast) ? true : false;
}

ASTNode.prototype.insertAfter = function(newSiblingNode){
	var index = this.getBlockIndex();
	var block = this.parentBlock();
	if(block.length - 1 > index)index++;
	return block.splice(index++,0,newSiblingNode.ast) ? true : false;
}

function mapResultsToNodes(ast, results){
	var ret = [];
	
	for(var i = 0; i < results.length;i++){
		var group = results[i];
		var groupArray = [];
		for(var x = 0; x < results[i].length; x++){
			var node = results[i][x].node;
			var nodePath = results[i][x].path;
			groupArray.push(new ASTNode(ast, node, nodePath));
		}
		ret.push(groupArray);
	}
	return ret;
}


