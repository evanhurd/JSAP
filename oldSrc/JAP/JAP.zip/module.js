module.exports = Mod;

function Mod(){
	this.ast = null;
	this.attributes = [];
}
